from flask import Flask, request, render_template, redirect, url_for, jsonify

from pymongo import MongoClient
import requests

app = Flask(__name__)

password = 'dewa123'
cxn_str = f'mongodb+srv://MuhammadRizkySamuel:123@cluster0.yxozh.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
client = MongoClient(cxn_str)

db = client.dbsparta_plus_week2

@app.route('/')
def main():
    return render_template('index.html')

@app.route('/detail/<keyword>')
def detail(keyword):
    print(keyword)
    return render_template('detail.html', word=keyword)

@app.route('/api/save_word', methods=['POST'])
def save_word():
    return jsonify({
        'result': 'success',
        'msg': 'word saved'
    })

@app.route('/api/delete_word', methods=['POST'])
def delete_word():
    return jsonify({
        'result': 'success',
        'msg': 'word deleted'
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
